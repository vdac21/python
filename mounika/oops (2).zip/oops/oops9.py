class student:
    def dispaly_marks(self):
        print("student marks")
        print(self)
s1=student()
s2=student()
print(s1)
s1.dispaly_marks()
print("-------s@-------")
print(s2)
s2.dispaly_marks()
    
