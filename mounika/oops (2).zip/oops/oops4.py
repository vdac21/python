class student:
    def display(self):
        print("hello world")

#display()
s1=student()
s1.display()
