#Accessing a class members (data or methods)
"""
the class members we can access object of that calss we can create an object of class using class name
"""
class student:
    pass

s1=student()
s1 is object of student class
