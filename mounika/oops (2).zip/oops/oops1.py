#oops:object oriented programing
#designing a software implementing re-usable components(object)
#so that one object can easily communicate with another object


"""
class: logical entity of an object
object:real entity
"""

#plan:logical view of your buliding
#Building:reality

#object
#person object
#object contains attributes & behaviours


"""

Attributes of an object can tell the state of the objects,the attributes of an object can be defined by using data types

name:string
ht:float
age:int

Behaviours of an object can tell the action doing the object.the object behaviours we can define as a functions


sleep()
walk()
"""
#the class can be defined with object properties(data,methods)

"""
The data inside a class we can called it as data members of a class the functions inside a class we can call it as member functions of class or simply we can say method
"""
#we can create multiple objects for same class each object creation
#we can call it has instances
