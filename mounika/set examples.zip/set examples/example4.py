#Remove items from the set at once

s1={10,20,30,40,50}
s1.difference_update({40,50})
print(s1)

