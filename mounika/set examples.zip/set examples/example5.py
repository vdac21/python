#Return a set of elements present in set A or B but not both


s1={10,20,30,40,50}
s2={30,40,50,60,70}

print(s1.symmetric_difference(s2))
