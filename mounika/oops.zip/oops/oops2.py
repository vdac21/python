#how to define a class

"""
class <classname>:

      #attributes
      #behaviours
"""

class student:
    def display():
        print("hello world")
    display()
    
    
