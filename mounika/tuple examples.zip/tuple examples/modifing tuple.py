#modify the tuple
tuple1=(11,[22,33],44,55)
tuple1[1][1]=222
tuple1[2]=22
print(tuple1)
