# Copy specific elements from one tuple to a new tuple

tuple1=(11,22,33,44,55,66)
tuple2=tuple1[2:-1]
print(tuple2)

              
