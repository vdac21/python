#Reverse the tuple

tuple=( 10,20,30,40,50 )

tuple=tuple[::-1]
print(tuple)
