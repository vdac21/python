#Unpack the tuple into 4 variables


tuple=(10,20,30,40,50)

a,b,c,d,e=tuple
print(a)
print(b)
print(c)
print(d)
print(e)
