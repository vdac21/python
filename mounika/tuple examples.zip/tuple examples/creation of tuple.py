#create a tuple with single item 50

tuple=(50, )
print(tuple)
