#count repeated  value

tuple1=(50,10,40,50,50)
print(tuple1.count(20))
