#Access value 20 from the tuple

tuple1=("orange",[10,20,30],(5,15,25))

#tuple1[0]='orange'
#tuple1[1]=[10,20,30]
#list1[1][1]=20

print(tuple1[0][1])
