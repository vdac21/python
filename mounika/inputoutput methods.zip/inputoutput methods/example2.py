#Display three string "Name","Is","James" as "Name**Is**James"

print('name','is','james',sep='**')

#convert float number to integer

num=8.9

print(int(num))


num=8

print(float(num))

