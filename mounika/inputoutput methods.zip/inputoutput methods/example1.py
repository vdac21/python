#Accept numbers from a user


num1=int(input("Enter first number "))
num2=int(input("Enter second number "))

result=num1*num2
print("multiplication is",result)
