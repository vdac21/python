#print the values of key 'history' from the below dict


sampleDict={
    "class":{
        "student":{
            "name":"mike",
              "marks": {
                "physics":70,
                "history":80
                }
            }
        }
    }
print(sampleDict['class']['student']['marks']['history'])
