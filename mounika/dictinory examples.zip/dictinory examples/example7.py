#get the key of a minimum value from the following dictionary

sample_dict={
    'ps':82,
    'math':65,
    'hs':75
    }
