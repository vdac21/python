#check if a value exists in a dictionary
sample_dict={'a':100,'b':200,'c':300}
