"""
#Inheritence


parents----->child


#Types of Inheritence


parent------>child       #single inheritence
parent1----->parent2----->child     #multilevel inheritence
father------mother
       child               #multiple inheritence


parent---->child1---->child2   #Hierarical inheritence
"""
