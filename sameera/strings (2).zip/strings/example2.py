#to display lowercase letters



word="AmaZOn"
res= " "
for ch in word:
    if ch>='a' and ch<='z':
        res=res+ch
print(res)
