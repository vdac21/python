class student:
    def __init__(self):
        print("inside init method")
    def marks(self):
        print("inside marks method")
    def display(self):
        print("inside display method")
#the student class contains or efinedor having 3 methods
#for student class we have created two objects i.e) s1 and s2
s1=student()
s2=student()
s1.marks()
s1.display()
s2.display()
