#Wap print all the numbers from the given list
#which are not divisiable by 5


x=[10,20,30,40,50,78]


for e in x:
    if e%5!=0:
        print(e)
print(x)


# which are diviable by 5
x=[10,20,30,40,50,78]


for e in x:
    if e%5==0:
        print(e)

