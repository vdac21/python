#wap print square

x=[1,2,3,4]
for e in x:
    print(e*e)
    


numbers=[1,2,3,4]
result=[x*x for x in numbers]
print(result)


x=[1,2,3,4]
res=[]

for i in x:
    res.append(i*i)
print(res)



