#wap print the numbers from 1 to 6

x=[1,2,3,4,5,6]
for i in x:
    print(i)


for i in range(1,7):
    print(i)
