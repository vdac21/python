import time

a=10
b=20
c=a+b
print("program is running.....")
time.sleep(10)
print(c)


