#reverse list

list1=[10,20,30,40,50]
list1.reverse()
print(list1)
