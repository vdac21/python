#concatenate two lists in following order

list1=['Hello','Take']
list2=['Dear','sir']

result= [x+y for x in list1 for y in list2]
print(result)



