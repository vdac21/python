#wap find maximum number between two numbers
'''
x= int(input("enter 1st value: "))
y= int(input("enter 2nd value: "))

if x>y:
    print(x)
if y>x:
    print(y)
'''    
x= int(input("enter 1st value: "))
y= int(input("enter 2nd value: "))

if x<y:
    print(x)
if y<x:
    print(y)
    
