#Wap find sum of all the elements  from the given list


x=[10,20,40,50]
s=0
for i in x:
    s=s+i
print(s)


x = -2
if x<0:
    print('freezing weather')
elif 0-10:
    print('very cold weather')
elif 10-20:
    print('cold weather')
elif 20-30:
    print('normal temp')
elif 30-40:
    print('its hot')
elif x>=40:
    print('its very hot')
else:
    print('program over')


#14)
