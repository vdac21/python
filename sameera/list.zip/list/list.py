v=[]
print(type(v))

v=[5,8,9,0,90]
print(v)
print(v[2])
print(v[-2])
print(v[0:4:2])
v.append(90)
print(v)
print(v.count(90))

