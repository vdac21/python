#WAP


x=["python","java","cpp","go"]
y= "  "

for word in x:
    print(word[0])
    y=y+word[0]
print(f"output:{y}")


#note: if any case we need to dispaly string  as an output
#we need to define empty string as a placeholder to store the output
    
