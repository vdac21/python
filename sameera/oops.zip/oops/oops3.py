#Accessing the class members


class student:
    pass
s1=student()


