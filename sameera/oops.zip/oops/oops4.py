class student:
    def display(self):
        print("hello")
s1=student()
s2=student()
s1.display()
s2.display()
