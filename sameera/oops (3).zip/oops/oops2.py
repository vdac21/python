#How to define a class
"""
class<classname>:
     #Attributes
     #behavaiours
     """
class student:
    def display():
        print("hello world")
display()  #nameerror:name display is not defined


"""
we can not access the class members directly
we need to access class members by using object of that class
"""
    

