'''
lower()
upper()
endswith()
startswith()
replace()
split()
count()
Rstrip()
lstrip()
strip()
removeprefix()
removesurfix()
index()
find()
'''


#programinglanguage="python easy"
#print(programinglanguage.upper())



programinglanguage="PYTHONEASY"
#print(programinglanguage.lower())
#print(programinglanguage.endswith("o"))
#print(programinglanguage.startswith("P"))
#print(programinglanguage.replace("Y","Z"))
#print(programinglanguage.split())
#print(programinglanguage.count("Z"))
#print(programinglanguage.removeprefix("P"))
print(programinglanguage.removesuffix("Y"))
print(programinglanguage.index("Y"))
print(programinglanguage.find("P"))


sum=     "addition  sum"
print(sum.strip())
print(sum.rstrip())
print(sum.lstrip())





