#reverse a string

str1 = "vedhu"
print("Original String is:", str1)

str1 = str1[::-1]
print("Reversed String is:", str1)
