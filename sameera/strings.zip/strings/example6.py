import time
s='BANGALORE'
print('Traversing list....')
print(s)

for ch in s:
    time.sleep(10)
    print(ch)
