"""
tuple operations

1.Conctenation
2.Iteration
3.Identity
4.membership
5.repetation
"""








t1=(1,2)
t2=(3,4)
print(t1+t2)



'''
t1=(1,2,3,4,5,6,7,8,9)
print(t1[0:5:2])
print(min(t1))
print(max(t1))
print(sum(t1))
print(len(t1))



t1=(1,2)
print(t1*3)


for i in t1:
    print(i)

print(1 in t1)
print(5 not in t1)

'''
t1=(1,2)
t2=(1,2)

print(t1 is t2)


