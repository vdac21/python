#Get Only unique items from the sets


s1={10,20,30,40,50}
s2={30,40,50,60,70}

print(s1.union(s2))
