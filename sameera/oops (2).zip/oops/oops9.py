class student:
    def display_marks(self):
        print("student marks")
        print(self)
s1=student()
s2=student()
print(s1)
s1.display_marks()
print("-------s@-------")

print(s2)
s2.display_marks()

        
