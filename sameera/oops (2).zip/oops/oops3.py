#Accessing the class members


class student:
    pass
s1=student()



1.Create a Class
2.Create Object
3.Create a class named Person, use the __init__() function to assign values for name and age?
