import math
print(math.pi)


import math


r=4

pie=math.pi

print(pie*r*r)



import math

r=math.sin(9)
print(r)
