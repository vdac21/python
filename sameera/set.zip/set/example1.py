# Add a list of elements to a set

sample_set={"Yellow","Orange","Green"}
sample_list=["Blue","Red","White"]
sample_set.update(sample_list)
print(sample_set)
