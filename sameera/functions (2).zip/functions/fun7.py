#local variables
>>> local variables are declared inside the function
>>>local variables acceesed only base function in the program
>>>local variable are alive with in the function they are declared

#global variables

>>> variable declared outside the main function
>>>global variables are accessed by all functions in the program
>>>global variables are alive throughout the program
