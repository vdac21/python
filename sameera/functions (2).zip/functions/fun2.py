#what are the purpose of the function

"""
code-re-usability


once you define a function we can call that function when ever we require
"""


def display():
    print("hi")
    print("hello")
    print("don't say bye")

display()

display()

display()
