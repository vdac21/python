"""*args and **kwargs"""


"""
1.In python we can pass a variable no.of arguments to function using special symbol.*args (non keyword args) and **kwargs(keyword args)
2.we use * notation (also called wild card) *args or **kwargs - as our function args when we are not sure about number of args we should pass in a function.
3.**kwargs in a function in python is used to pass keyworded ,variable length argument list.A keyword args is where you provide a name to the variable as you pass it into function
"""
