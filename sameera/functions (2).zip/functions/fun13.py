#default vs non default args
#WAF add two numbers
#add function with two params

def add(x,y):
    c=x+y
    return c
x=10
y=20
r=add(x,y)  #calling function
print(f"sum of x={x} and y={y} is r={r}")
