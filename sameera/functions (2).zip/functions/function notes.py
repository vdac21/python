"""
Id()--- takes an object and retirns address
type()--- takes an object and returns type of the object
ord(),---takes a char(string) and returns ascii value
len()---- takes sequence objectand returns size of the object
"""
#function:Built in functions

#Defination:
"""
A function is a piece code and it will perform a specific task or job

the function takes args
the function return values
"""
"""
s1="ongole"
s1.upper()-->upper(s1)'ONGOLE'


1.job of the function:converting given lower string to upper string
2.taking:string as input
3.Returning:string as output

"""
#index
x=[1,2,3,4,5]
x.index(3)
#job:Identifying indexing of a given value
#taking:list and number
#returning:---value
