#we need a call function by passing the required args

def add(x,y):
    c=x+y
    print(c)

add(4,6)

add(9,0)


add(50,60)
