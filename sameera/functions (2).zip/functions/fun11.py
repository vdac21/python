#Define a function to compute area of rectangle



def rect_area(l,b):
    a=l*b
    return a
ar=rect_area(10,20)
print(ar)
ar1=rect_area(90,0)
print(ar1)
