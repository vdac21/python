#creating Dict


dict={1:'happy',2:'with',3:'you'}
print("\nDictionary with use of integer keys: ")
print(dict)


dict={'name':'sameera','middle':'bheri','lastname':'B'}
print("\nDictionary with use of string keys: ")
print(dict)
