#change value of key in a nested dictionary

dict={
    'emp1':{'name':'jhon','salary':7500},
    'emp2':{'name':'emma','salary':8000},
    'emp3':{'name':'brad','salary':500},
    }
    
dict['emp3']['salary']=8500
print(dict)
