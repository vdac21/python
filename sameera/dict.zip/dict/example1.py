Dict={1:'very',2:'good',3:'morning'}
print(Dict)



dict={
    'ps':82,
    'math':90,
    'ss':76
    }
print(min(dict.values()))
