#Terminology


#Function defination

#function call

#Function parameters

#Function return value

#How to defined function

"""


We can define a def keyword to defined a function

#syntax

def<function_name>(args):
    #st1
    #st2
    #st3
    #
    #
"""

def display():
    print("hello")
display()

