#WAF to sum two values and multiply results with 100



def add(x,y):
    c=x+y
    print(c)
    #r=c*100
    #print(r)
add(10,20)
print(c*100)

""" The variables which we have defined inside a function are the local variables,we are not access outside of the function,to get the value outside of the function,we need to return the value from the function"""
"""we can return values from the function by using return statement"""

