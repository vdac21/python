#WAF find sum of two numbers

def add():
    c=x+y
    print(c)
add()
#NameError: name 'x' is not defined
#TypeError: add() missing 2 required positional arguments: 'x' and 'y'

