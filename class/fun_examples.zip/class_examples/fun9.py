

def find_square(num):
    result = num*num
    return result

square = find_square(3)

print('Square: ',square)
 
