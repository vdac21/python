import math

square_root = math.sqrt(4)

print("square Root of 4 is",square_root)

power = pow(2, 3)

print("2 to the power 3 is",power)
