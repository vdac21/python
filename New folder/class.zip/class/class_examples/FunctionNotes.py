"""
id()   --->   takes an object and returns address
type() --->   takes an object and returns type of an object 
ord(), --->   takes a char (string) and returns ascii value
len()  ---> > takes sequnce object and returns  size of the object 

"""

# Function :  Built-In functions

# Definition:

"""
A function is a peice code and it will perfrom a specific task or job


The fuction takes args
The function returns values
"""
"""
> s1 = "hyderabad"
>>> s1.upper()  --> upper(s1)
'HYDERABAD'

1. Job of the function : Converting given lower case string to upper case
2. Taking  :  string as input 
3. Returning  : string as output 
"""
# index
x = [10, 20, 30, 40]
x.index(30)
# JOB:   --->    Indetifying indexing of a given value 
# Taking:  -->    LIST AND NUMBER 
# Returning: -->  NUMBER



