#WAF find area of circle
#formula : Pi*r*r
def area(r):
    pi=3.147
    a=pi*r*r
    return a
rad=10
#calling a function:we can call a function by using function name
#and while we are calling function we must Pass the required params

a1= area(rad)
print(a1)
    
