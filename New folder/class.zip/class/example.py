
#x = [10, 20, 30, 40]


# Get each and every element
"""
print(x[0])
print(x[1])
print(x[2])
print(x[3])
"""

#print(x[4])  # IndexError: list index out of range


# SYNTAX

"""
for <var> in <Sequnce>:
    # st1
    # st2
    # st3
    :
    :
    :
    St N
Note: The seaunce can be list , tuple , string or any python sequnce of objcet
var :  is a iteration variable , you can take any meaning full name 
"""

x = [10, 20, 30, 40]

for i in x:
    print(i)









