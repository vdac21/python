

# Noraml Program Execution :
#driver a bike / car : 60KM/HR

# How much time will take to drive 120KM?


# Conditions?

# How many signals in between ?

# Which is the route choosen?

# How  many speed breakers in the route?

# is the speed limit entire 20K is same or not?


x = [16, 19, 18, 15, 71, 25, 65, 30, 67]

# write program for each eleemnt
# REq print only the numbers which  are div by 5

# print the number which are not divisible by 5 
