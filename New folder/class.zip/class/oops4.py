class Student:
 
    def display(self):
        print("Hello Wolrd!")



#display()
s1 = Student()  
s1.display()    
