# Conditional Statements
"""
if

if - else

if elif .... lader
"""

# if - statement / block

# SYNTAX
"""
if <condition>:
   # st1
   # st2
   :
   :
   # stn
The statement inside if-block will execute when the condition is true
other wise the statements inside if-block will not execute
"""

print("St1")
print("St2")

if True:
    print("St3")
    print("St4")

print("St5")
print("St6")





