# Recursive Function : calling same function itself

# 5! = 5 * 4 * 3 * 2 * 1
"""
5! = 5 * 4!
4! = 4 * 3!
3! = 3 * 2!
2! = 2 * 1!
1! = 1
"""


def get_fact(n):
    pass


r = get_fact(7)
print(r)
