# WAF find area of circle

"""
def <fun_name>(arg):
    # st1
    # st3
    return statement
"""
# If you are not retunring anything function ,
# the interpreter will return None value

# formala :  pi * r * r
def area(r):
    pi = 3.147
    a = pi*r*r
    return a


rad = 10

# calling a function : We can call a function by using function name
# and while we are calling function we must pass the required params


a1 = area(rad)

print(a1)
