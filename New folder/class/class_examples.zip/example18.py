"""
If we have more than two condition and at a time one condition needs to
be execuetd we can dfine if - elif ladder

# SYNTAX

if <cond1>:
    st1
elif <cond2>:
    st3
elif <cond3>:
    st4
:
:
else:
    st # optional 
"""

x = int(input("Enter a value : "))
if x == 1:
    print("ONE")
elif x == 2:
    print("TWO")
elif x == 3:
    print("THREE")
else:
    print("Numebr is graeter than")
    





