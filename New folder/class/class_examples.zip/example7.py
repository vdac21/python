#   WAP find sum of all the elemets from the given list


x = [2, 4, 6, 8]

# Expected output : 20

s = 0 # This is place holder to store the output 


for i in x:
    s = s+i

print(s)
