"""
fobj = open('sample.txt', 'r')
text = fobj.read()
fobj.close()
"""

# Writing data inside a file
# open

f = open('output.txt', 'w')

# write
f.write("Hello Welcome to Python")

# close
f.close()
