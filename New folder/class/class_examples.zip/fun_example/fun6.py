#  WAF to sum two values and multiply results with 100


def add(x, y):
    c = x+y
    return c

r = add(10, 20)
print(r) # contains retunrn value of the add function i.e 30

print(r*100)


