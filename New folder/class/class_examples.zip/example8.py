# SYNTAX OF FOR LOOP
"""
for <var> in <sequnce>:
    # Line1
    # Line2
    # Line3
    :
    :
    # Line4

"""
#  A loop is a iterative statement or repetive statement
# We need to think
# how many time the statement
# inside loop will execute 
print("St-1")   # Outside of the loop & its execute before loop execution
print("St-2")   # Outsode of the loop  & its execute before loop execution

for i in range(5):
    print("St-3") # inside a loop 
    print("St-4") # inside a loop
    print("St-5") # insdie a loop

print("St-6")  # Outside of the loop & its execute after loop execution
print("St-7")  # Outside of the loop & its execute after loop execution

# Note: The loop will execute 5 time and whateber the statements insid a
# loop will execute 5 time 

