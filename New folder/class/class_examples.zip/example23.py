# WAP find sum of all the numbers which are divisible by 5

x = [10, 16, 15, 18, 85, 73, 54]

#output --> NUmber

s = 0 # s palce holder to store the output

for e in x:
    if e % 5 == 0:
        s = s+e

#outside
print(e)


