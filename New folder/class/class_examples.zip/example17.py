# WAP find maximum number between two numbers 

"""
x = int(input("Enter 1st value: "))
y = int(input("Enter 2nd value: "))

if x > y:
    print("X is maximum value")
if y > x:
    print("Y is maximum value")
"""

#  How many inputs : 2 inputs
#  How many conditions : 2 conditions
#  How many conditions are being executed : 1
"""
When we have two conditions but at a time one condition you need execute means

we can go for if -else isntead of writing two if statements

if <condition>:
     st1
     st2
     st3
else:
     st4
     st5

When teh condition is true the statements inside if-block will run
otherwise teh statements inside else block will run, so the above program can be re-writen as below
"""

x = int(input("Enter 1st value: "))
y = int(input("Enter 2nd value: "))
if x > y:
    print("X is maximum value")
else:
    print("Y is maximum value")








