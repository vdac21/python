"""
Write a program count each occurrence of a vowel from the given string
"""

s = input("Enter a string: ") #"indai"
s = s.lower()
d = {}
vowels = "aeiou"
for ch in s:
    if ch in vowels:
        if ch not in d:
            d[ch] = 1  # Adding new key value pair {'i':1, 'a':1}
        else:
            d[ch] = d[ch] +1 # Updating existing key value pair {'i':2, 'a':1}
print(d)
