"""
Write a program to reverse the given input string.
"""


s = "PYTHON"

reverse_s = ""

for i in range(len(s)-1, -1, -1):





YOU ARE CHIRANJEEVI

max() ,  join()    reverse() 
    
