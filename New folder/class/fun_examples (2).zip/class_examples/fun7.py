def greet():
    print("Hello world")
#call the function
    greet()

#print("outside the function")
