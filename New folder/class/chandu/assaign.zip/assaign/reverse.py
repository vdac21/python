list1 =[100,200,300,400,500]
list1.reverse()
print(list1)
