list1=["M","Na","i","Ke"]
list2=["y","me","s","lly"]
list3=[i+j for i,j in zip(list1,list2)]
print(list3)
