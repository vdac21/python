#Runtime Errors or Exceptions

#Exception Handling



#To handle teh exceptions we can use below statements or keywords
"""

Try:-->Which ever the excpetional causing statements we neep keep inside block


Except:

Once exception arises what action user or programer can take, the code goes inside except block
