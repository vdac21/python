#HOW TO DEFINE A CLASS
"""class <classname>:
        #Attributes
        #Behaviours"""

class student:
    def display():
        print("hello world")
display()
