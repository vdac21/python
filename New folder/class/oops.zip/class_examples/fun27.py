'''python local variables:


    Local variables in python are those which are initilized inside a function and belong only to that particular function.It cannot accessed anywhere outside the function.

    example:'''
def f():
    #local variable
    s="chandu"
    print(s)
f()
print(s)
