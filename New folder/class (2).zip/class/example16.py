# WAP find maximum number between two numbers 

x = int(input("Enter 1st value: "))
y = int(input("Enter 2nd value: "))

if x > y:
    print("X is maximum value")
if y>x:
    print("Y is maximum value")
