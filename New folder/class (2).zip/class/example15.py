print("St1")
print("St2")

if 5>2 and 6>10: # if True and False:  # if False:
    print("St3")
    print("St4")

print("St5")
print("St6")

