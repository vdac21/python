
x = 10
def add(x, y):
    c = x+y
    return c


r = add(10, 20)
print(x)
print(c*100)
