print("St1")
print("St2")

if False:
    print("St3")
    print("St4")

print("St5")
print("St6")
