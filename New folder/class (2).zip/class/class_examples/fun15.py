#Define a function to compute area of rectangle

#l*b


def rect_area(l,b):
    a=l*b
    return a

ar= rect_area(10,20)
print(f"Area of Rect is {ar}")
