#OOps : OBJECT ORIENTED PROGRAM
#Designing a software by implementing re-uasble
#So that one object can easily communicate with another object


"""Class vs OBJECT

CLASS : LOGICAL ENTITY OF OBJECT
OBJECT:REAL ENTITY

"""

#plan--->logical view of your buliding
#BUILDING1-->Reality
#BUliding2-->Reality


#OBJECT
#PERSON OBJECT
#OBJECT CONTAINS ATTRIBUTES & BEHAVIOURS


"""
Attributes of an object can tell the state of the object
The Attributes of an object can be defined by using  data types

name-string
ht:float
age:int

Behaviours of an object can tell the action doing the object
The object behaviours we can define as functions
sleep()
walk()
"""
"""
#the class can be defined with object properties(data,methods)

"""
The data inside a class we can called it as d
a class.
The functions inside a class we can call it as member functions of a class

# we can create multiple objects for same class-- each object creation
#we can call it as instance of class
or simply we can say methods
