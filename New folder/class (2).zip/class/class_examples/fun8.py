#function with two arguments
def add_num(num1, num2):
    sum = num1 + num2
    print('Sum: ' ,sum)

add_num(5, 4)
