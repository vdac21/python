# WAF to sum two values and multiply results with 100

def add(x,y):
    c=x+y
    return c

r= add(2,3)
print(r)
print(r*100)
