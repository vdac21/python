import time

x = [10, 20, 30, 40]
print("Traversing a list.......")
print(x)
for i in x:
    time.sleep(3)
    print(i)
    



s = "BANGALORE"
print("Travesing a string.....")
for ch in s:
    time.sleep(3)
    print(ch)
    


t  = (10, 200, 300)
print("Travesing a tuple.....")
for e in t:
    time.sleep(3)
    print(e)
