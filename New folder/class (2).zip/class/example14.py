print("St1")
print("St2")

if 5>2 or 6>10: # if True or False:  # if True
    print("St3")
    print("St4")

print("St5")
print("St6")
