# WAP print all the numbers from the given list
# which are divisible by 5 

x = [10, 16, 15, 18, 85, 73, 54]

for e in x:
    # check the number is divisible by 5 or not
    if e % 5 == 0: 
        print(e)


#iteration1: # if 10% 5 == 0 :  --> if 0==0:  if True:

#iteration2: # if 16% 5 == 0 :  --> if 1==0:  if False:
