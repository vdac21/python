# WAP find square of each and every element from the given list
# and dispaly output in list format
# Expected Output
# [4, 16, 36, 64]
x = [2, 4, 6, 8] # input

y = [] # place hoder to display the output
for e in x:
    y.append(e*e)
    #print(y)

print(y)


#  


