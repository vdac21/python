# WAP print all the numbers from the given list
# which are not divisible by 5 

x = [10, 16, 15, 18, 85, 73, 54]


for e in x:
    if e % 5 != 0:
        print(e)
