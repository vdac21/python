# input & output 

#By using  print() function we can display the output to the user

#By using input() function we can take input from the user 


# ADD TWO NUMBERS


#a = 10
#b = 20
a = input("Enter value of a: ") # waits the user input 100
b = input("Enter value of b: ") # waits the user input 200

#print("User Entered values a, b", a, b)
c = int(a)+int(b) # "100"+"200"


print("Output", c)
