#  WAP print square of each and every element from the given list

# visit or Traverse or Iterate

# Expected :  4, 16, 36, 64
x = [2, 4, 6, 8]

for e in x:
    print(e*e)





# Be happy incase if you undersatnd this program
