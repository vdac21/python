# We need a call function by passing the required args

def add(x, y):
    c  = x+y
    print(c)


add(10, 20)


add(30, 50)
